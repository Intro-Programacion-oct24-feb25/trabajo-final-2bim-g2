/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package papresentacion;

/**
 *
 * @author Usuario iTC
 */
public class ReporteCompleto {
    public static void obtenerReporteFinal(String info, String reporte,
                                           String ca){
        
        System.out.printf("\nEl deporte para la vida\n%s\n%s\n%s\n",
                info, reporte, ca);       
    }
}
